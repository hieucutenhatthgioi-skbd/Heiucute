# Discord Username Checker (4C / 4L)

A small local web app that checks a **user-supplied shortlist** through the Apify Actor `maged120/discord-username-checker`.

## Requirements
- Node.js 18+
- An Apify account and API token
- Actor access/credits as required by Apify

## Run locally
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Put your Apify token in `.env`:
   ```env
   APIFY_TOKEN=your_real_token
   PORT=3000
   ```
6. Start:
   ```bash
   npm start
   ```
7. Open `http://localhost:3000`.

## Modes
- **4C**: accepts a supplied username with exactly four characters. The Actor decides whether the characters are valid for Discord.
- **4L**: accepts exactly four English letters (`A-Z`).
- Up to 500 unique usernames per request, matching the Actor's documented batch limit.
- Results: Available / Taken / Unknown.
- Export available results to TXT.

## Security
- The Apify token is read only by the server from `.env`; it is never sent to the browser.
- Do not upload `.env` or share your API token.
- This app intentionally does not generate or exhaustively enumerate every possible username combination. Use a shortlist you chose.
- Availability can change before you attempt to register a username.

## Actor and API
Actor page: https://apify.com/maged120/discord-username-checker

The server calls:
`POST https://api.apify.com/v2/actors/maged120~discord-username-checker/run-sync-get-dataset-items`

with JSON input:
`{"usernames":["name1","name2"]}`

The Actor page documents a maximum of 500 usernames per run.
