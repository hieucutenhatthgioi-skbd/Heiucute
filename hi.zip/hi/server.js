require("dotenv").config();

const express = require("express");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ACTOR_URL =
  "https://api.apify.com/v2/actors/maged120~discord-username-checker/run-sync-get-dataset-items";

app.use(express.json({ limit: "256kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/check", async (req, res) => {
  const token = process.env.APIFY_TOKEN;
  if (!token || token === "YOUR_APIFY_TOKEN_HERE") {
    return res.status(503).json({
      error: "Chưa cấu hình APIFY_TOKEN. Hãy tạo file .env từ .env.example."
    });
  }

  const mode = req.body?.mode;
  const raw = req.body?.usernames;

  if (!["4c", "4l"].includes(mode) || !Array.isArray(raw)) {
    return res.status(400).json({ error: "Dữ liệu gửi lên không hợp lệ." });
  }

  const usernames = [...new Set(
    raw.map(v => String(v).trim()).filter(Boolean)
  )];

  if (usernames.length === 0) {
    return res.status(400).json({ error: "Hãy nhập ít nhất một username." });
  }
  if (usernames.length > 500) {
    return res.status(400).json({
      error: "Mỗi lần tối đa 500 username theo giới hạn của Actor."
    });
  }

  const invalid = usernames.filter(name =>
    mode === "4l" ? !/^[a-z]{4}$/i.test(name) : [...name].length !== 4
  );
  if (invalid.length) {
    return res.status(400).json({
      error: mode === "4l"
        ? `4L chỉ nhận đúng 4 chữ cái A-Z. Không hợp lệ: ${invalid.slice(0, 8).join(", ")}`
        : `4C chỉ nhận username có đúng 4 ký tự. Không hợp lệ: ${invalid.slice(0, 8).join(", ")}`
    });
  }

  try {
    const response = await fetch(ACTOR_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ usernames }),
      signal: AbortSignal.timeout(300000)
    });

    const bodyText = await response.text();
    if (!response.ok) {
      return res.status(502).json({
        error: `Apify trả về lỗi HTTP ${response.status}. Kiểm tra token, số dư và cấu hình Actor.`,
        details: bodyText.slice(0, 500)
      });
    }

    let data;
    try {
      data = JSON.parse(bodyText);
    } catch {
      return res.status(502).json({ error: "Phản hồi từ Apify không phải JSON hợp lệ." });
    }

    const rows = Array.isArray(data) ? data : [];
    const results = rows.map(row => ({
      username: String(row.username ?? ""),
      available: typeof row.available === "boolean" ? row.available : null,
      error: row.error ?? null
    }));

    return res.json({ results });
  } catch (error) {
    const timedOut = error.name === "TimeoutError" || error.name === "AbortError";
    return res.status(502).json({
      error: timedOut
        ? "Actor chạy quá thời gian chờ. Hãy thử danh sách nhỏ hơn."
        : "Không kết nối được Apify. Kiểm tra mạng rồi thử lại."
    });
  }
});

app.listen(PORT, () => {
  console.log(`Discord Username Checker running at http://localhost:${PORT}`);
});
